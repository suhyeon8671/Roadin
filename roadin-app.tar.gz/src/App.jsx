import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import SignUp from './pages/SignUp';
import MyPage from './pages/MyPage';
import Story from './pages/Story';
import Chat from './pages/Chat';
import Diagnosis from './pages/Diagnosis';
import './App.css';

function App() {
  return (
    <Router>
      <AuthProvider>
        <div className="App">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/mypage" element={<MyPage />} />
              {/* 스토리 페이지에 대한 동적 라우팅 추가 */}
              <Route path="/story" element={<Story />} />
              <Route path="/story/:category" element={<Story />} />
              <Route path="/chat" element={<Chat />} />
              <Route path="/diagnosis" element={<Diagnosis />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </AuthProvider>
    </Router>
  );
}

export default App;
