import { Link, useNavigate } from 'react-router-dom';
import { HashLink } from 'react-router-hash-link';
import { getAuth, signOut } from 'firebase/auth';
import { FaUser } from 'react-icons/fa';
import './Header.css';

function Header({ user }) {
  const navigate = useNavigate();
  const auth = getAuth();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <header className="header">
      <div className="header-left">
        <Link to="/" className="logo">
          Roadin
        </Link>
      </div>
      <nav className="header-nav">
        <ul>
          <li><Link to="/story">Roadin 이야기</Link></li>
          <li><HashLink smooth to="/#how-to-use">서비스 소개</HashLink></li>
          <li><Link to="/chat">길동이와 대화하기</Link></li>
          {user ? (
            <>
              <li>
                <Link to="/mypage" className="profile-icon">
                  <FaUser />
                </Link>
              </li>
              <li>
                <button onClick={handleLogout} className="logout-button-nav">로그아웃</button>
              </li>
            </>
          ) : (
            <li><Link to="/login">로그인</Link></li>
          )}
        </ul>
      </nav>
    </header>
  );
}

export default Header;
