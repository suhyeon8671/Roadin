import React from 'react';
import './TrendingJobs.css';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const jobs = [
  {
    name: 'AI 전문가',
    description: '인공지능 기술을 연구하고 개발하여 다양한 문제에 적용하는 전문가입니다.',
    popularity: 95,
  },
  {
    name: '데이터 사이언티스트',
    description: '방대한 데이터 속에서 의미 있는 정보를 찾아내 비즈니스 의사결정을 돕습니다.',
    popularity: 92,
  },
  {
    name: 'UI/UX 디자이너',
    description: '사용자에게 편리하고 매력적인 디지털 경험을 제공하기 위해 화면을 설계합니다.',
    popularity: 88,
  },
  {
    name: '소프트웨어 개발자',
    description: '컴퓨터 언어를 사용하여 웹, 앱, 시스템 등 다양한 소프트웨어를 만듭니다.',
    popularity: 85,
  },
  {
    name: '정보보안 전문가',
    description: '해킹, 바이러스 등 외부 위협으로부터 조직의 정보 자산을 안전하게 보호합니다.',
    popularity: 82,
  },
];

const chartData = {
  labels: jobs.map(job => job.name),
  datasets: [
    {
      label: '인기도',
      data: jobs.map(job => job.popularity),
      backgroundColor: [
        '#FFDDC1', // 파스텔 피치
        '#FFABAB', // 파스텔 레드
        '#FFC3A0', // 파스텔 오렌지
        '#B5EAD7', // 파스텔 민트
        '#A2D2FF', // 파스텔 블루
      ],
      borderColor: '#ffffff',
      borderWidth: 2,
      borderRadius: 5,
    },
  ],
};

const chartOptions = {
  indexAxis: 'y',
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { display: false },
    tooltip: { enabled: false },
  },
  scales: {
    x: { display: false },
    y: { display: false },
  },
};

function TrendingJobs() {
  return (
    <div className="trending-jobs-container">
      <h2>요즘 뜨는 직업 TOP 5</h2>
      <div className="content-wrapper">
        <div className="chart-wrapper">
          <Bar data={chartData} options={chartOptions} />
        </div>
        <div className="jobs-list">
          {jobs.map((job, index) => (
            <div key={index} className="job-item">
              <h3>{job.name}</h3>
              <p>{job.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default TrendingJobs;
