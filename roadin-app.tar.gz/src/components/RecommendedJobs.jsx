import React from 'react';
import { Link } from 'react-router-dom';
import './RecommendedJobs.css';

const recommendedJobs = [
  { 
    id: 'web-developer', 
    title: '웹 개발자', 
    reason: 'IT 및 코딩에 대한 높은 흥미를 바탕으로 추천합니다.',
    storyPath: '/story/it' 
  },
  { 
    id: 'digital-marketer',
    title: '디지털 마케터',
    reason: '창의성과 데이터 분석 능력을 동시에 활용할 수 있는 직무입니다.',
    storyPath: '/story/marketing'
  },
  { 
    id: 'product-manager',
    title: '프로덕트 매니저(PM)',
    reason: '문제 해결과 커뮤니케이션 능력을 바탕으로 제품의 성장을 이끌 수 있습니다.',
    storyPath: '/story/pm'
  },
];

function RecommendedJobs() {
  return (
    <div className="recommended-jobs-container">
      <h2>회원님과 비슷한 사람들이 선택한 진로</h2>
      <div className="recommended-list">
        {recommendedJobs.map(job => (
          <div key={job.id} className="recommended-item">
            <h3>{job.title}</h3>
            <p>{job.reason}</p>
            <Link to={job.storyPath} className="details-button">
              자세히 보기
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}

export default RecommendedJobs;
