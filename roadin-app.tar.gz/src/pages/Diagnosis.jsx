import React, { useState } from 'react';
import './Diagnosis.css';
import { surveyData } from '../data/surveyData';

const initialFields = [
  { name: 'IT/개발', emoji: '💻' },
  { name: '디자인', emoji: '🎨' },
  { name: '마케팅', emoji: '📈' },
  { name: '기획', emoji: '📝' },
  { name: '금융', emoji: '💰' },
  { name: '교육', emoji: '🎓' },
];

function Diagnosis() {
  const [currentStep, setCurrentStep] = useState('selection'); // selection, questions, results
  const [selectedField, setSelectedField] = useState(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState([]);
  const [recommendedJobs, setRecommendedJobs] = useState([]);

  const handleFieldSelect = (fieldName) => {
    if (surveyData[fieldName] && surveyData[fieldName].questions.length > 0) {
      setSelectedField(fieldName);
      setCurrentStep('questions');
    } else {
      alert(`${fieldName} 분야는 현재 준비중입니다.`);
    }
  };

  const handleAnswerSelect = (optionIndex) => {
    const questionId = surveyData[selectedField].questions[currentQuestionIndex].id;
    const newAnswers = [...answers, `${questionId}_${optionIndex}`];
    setAnswers(newAnswers);

    const questions = surveyData[selectedField].questions;
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Calculate results with advanced logic
      const jobs = surveyData[selectedField].jobs;
      const jobScores = jobs.map(job => {
        const score = job.keywords.reduce((acc, keyword) => {
          return newAnswers.includes(keyword) ? acc + 1 : acc;
        }, 0);
        return { ...job, score };
      });

      // Sort jobs by score in descending order
      const sortedJobs = jobScores.sort((a, b) => b.score - a.score);
      
      // Filter jobs with a score > 0, or show all if no matches
      const finalJobs = sortedJobs.filter(job => job.score > 0);

      setRecommendedJobs(finalJobs.length > 0 ? finalJobs : jobs);
      setCurrentStep('results');
    }
  };

  const handleReset = () => {
    setCurrentStep('selection');
    setSelectedField(null);
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setRecommendedJobs([]);
  };

  const renderSelection = () => (
    <div className="diagnosis-intro">
      <h2>관심있는 취업 분야를 선택해 주세요.</h2>
      <p>하나만 선택해 주세요. 나중에 변경할 수 있습니다.</p>
      <div className="field-options">
        {initialFields.map((field) => (
          <button 
            key={field.name} 
            className="field-button"
            onClick={() => handleFieldSelect(field.name)}
          >
            <span className="field-emoji">{field.emoji}</span>
            <span className="field-name">{field.name}</span>
          </button>
        ))}
      </div>
    </div>
  );

  const renderQuestions = () => {
    if (!selectedField) return null;
    const question = surveyData[selectedField].questions[currentQuestionIndex];
    const totalQuestions = surveyData[selectedField].questions.length;
    return (
      <div className="question-container">
        <div className="progress-bar">
            <div className="progress" style={{ width: `${((currentQuestionIndex + 1) / totalQuestions) * 100}%` }}></div>
        </div>
        <h2>{selectedField} 분야 질문</h2>
        <p className="question-text">{`Q${currentQuestionIndex + 1}. ${question.text}`}</p>
        <div className="options-grid">
          {question.options.map((option, index) => (
            <button key={index} className="option-button" onClick={() => handleAnswerSelect(index)}>
              {option}
            </button>
          ))}
        </div>
      </div>
    );
  };

  const renderResults = () => (
    <div className="results-container">
      <h2>'{selectedField}' 분야에 대한 추천 직업</h2>
      <p>설문 결과를 바탕으로 당신의 성향과 가장 잘 맞는 직업을 추천해 드립니다.</p>
      <div className="job-cards">
        {recommendedJobs.map((job, index) => (
          <div key={index} className="job-card">
            <h3>{job.name}</h3>
            <p>{job.description}</p>
            {job.score && <span className='job-score'>적합도: {job.score}</span>}
          </div>
        ))}
      </div>
      <button onClick={handleReset} className="cta-button primary">다시하기</button>
    </div>
  );

  return (
    <div className="diagnosis-container">
      {currentStep === 'selection' && renderSelection()}
      {currentStep === 'questions' && renderQuestions()}
      {currentStep === 'results' && renderResults()}
    </div>
  );
}

export default Diagnosis;
