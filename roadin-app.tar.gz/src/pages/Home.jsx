import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import Hero from '../components/Hero';
import ServiceIntroduction from '../components/ServiceIntroduction';
import HowToUse from '../components/HowToUse';
import TrendingJobs from '../components/TrendingJobs';
import RecommendedJobs from '../components/RecommendedJobs';

function Home() {
  const { user } = useAuth();

  return (
    <>
      <Hero />
      {user ? (
        <>
          <TrendingJobs />
          <RecommendedJobs />
        </>
      ) : (
        <>
          <ServiceIntroduction />
          <HowToUse />
        </>
      )}
    </>
  );
}

export default Home;
