import { useState, useEffect } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import './MyPage.css';

function MyPage({ user }) {
  const [job, setJob] = useState('');

  useEffect(() => {
    const fetchUserData = async () => {
      if (user) {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setJob(docSnap.data().job);
        }
      }
    };
    fetchUserData();
  }, [user]);

  if (!user) {
    return <p>로그인이 필요합니다.</p>;
  }

  return (
    <div className="mypage-container">
      <h2>마이페이지</h2>
      <div className="user-info">
        <p><strong>이메일:</strong> {user.email}</p>
        <p><strong>직업:</strong> {job}</p>
      </div>
    </div>
  );
}

export default MyPage;
